Steps to run -

1) Import all 4 projects in STS as Maven Projects
2) Run them all as Spring Boot App in order
    - ServiceDiscovery
    - Services(Admin/Customer)
    - APIGateway
