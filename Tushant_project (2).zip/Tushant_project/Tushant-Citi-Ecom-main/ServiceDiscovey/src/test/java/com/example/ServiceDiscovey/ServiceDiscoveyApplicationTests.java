package com.example.ServiceDiscovey;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceDiscoveyApplicationTests {

	@Test
	void contextLoads() {
	}

}
